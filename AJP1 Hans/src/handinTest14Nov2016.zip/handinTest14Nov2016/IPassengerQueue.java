package handinTest14Nov2016;

public interface IPassengerQueue{

	void putPassengerInQueue(Passenger p);

	Passenger getNextPassenger();
}
