package handinTest14Nov2016;

import java.util.Queue;

public class PassengerQueue implements IPassengerQueue {

	private LinkedQueue<Passenger> queue;

	public  PassengerQueue()
	{
		this.queue = new  LinkedQueue<Passenger>(true);

	}

	@Override
	public synchronized void putPassengerInQueue(Passenger p) {
		queue.enqueue(p);

	}

	@Override
	public synchronized Passenger getNextPassenger() {
		Passenger temp =  queue.dequeue();
		return temp;
	}

}
