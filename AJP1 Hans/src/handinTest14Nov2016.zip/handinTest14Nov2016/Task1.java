package handinTest14Nov2016;

public class Task1 {

	public static double calcPower(double x, int n) {
		if (n == 0) {
			return 1;
		} else if (n == 1 && x != 0) {
			return x;
		} else if (x == 0) {
			return 0;
		}

		else

			return x * calcPower(x, n - 1);
	}

	public static long factorial(int n) {
		/*
		 * Recursive version
		 * if (n == 0) 
		 * return 1; 
		 * else 
		 * return n * factorial(n - 1);
		 */
		int result = n;
		for (int i = 1; i < n; i++) {
			result = result * i;
		}
		return result;
	}
	
	
	public static long exp()
	{
		
	}
	

	public static void main(String[] args) {

		
		System.out.println("Power: "+calcPower(12, 2));
		System.out.println("Factorial: "+factorial(5));

	}

}
